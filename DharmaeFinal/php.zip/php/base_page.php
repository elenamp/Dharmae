<!-- Página base para empezar a crear nuevas páginas (terapias, contacto, quienes somos...)-->
<?php require_once("funciones/headerAndFooter.php");?>
<html>
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link type="text/css" rel="stylesheet" href="../css/EstilosIndex.css">
    </head>
    <body>
        <header>
            <?php cabecera();?>   
        </header>
        <div id="cuerpo"> 
                      
        </div>
        
        <footer>
            <?php pieDePagina();?>
        </footer>
    </body>
</html>